# Nabdha AI - Test Datasets

Generated 2026-09-26 - 15 synthetic SME datasets for testing data upload, cleaning and the AI analysis engine.
Each workbook has 6 sheets matching the platform's upload categories: Sales, Inventory, Customers, Orders, Payments, Delivery,
plus a Notes sheet describing the test's purpose and the signal it is designed to trigger.
All figures are in SAR. All data is synthetic/fictional.

| # | File | Test company | Focus | Expected signal |
|---|------|--------------|-------|------------------|
| 01 | `01_healthy_growth_sme.xlsx` | Rawnaq Retail Co. | Baseline / happy path: steady, healthy multi-category retail growth with clean data. | Positive growth trend, no major risks, Business Health Score should read comfortably healthy (75-90). |
| 02 | `02_declining_sales_trend.xlsx` | Baraka General Trading | Sales Signal Detection: month-on-month revenue decline in the second half of the period. | Risk: 'Declining sales' should fire once the trailing-30/60-day window crosses the drop-off around day 90. |
| 03 | `03_sales_spike_and_drop.xlsx` | Waha Home Essentials | Anomaly detection: a 3-day promotional spike (~4.5x) followed later by a sudden multi-day drop. | Two distinct anomaly signals expected: an unusual spike around day 60-62 and an unusual drop around day 90-93. |
| 04 | `04_single_product_concentration.xlsx` | Anwar Perfumes | Customer/Revenue concentration risk: one SKU (Oud Perfume) drives the large majority of revenue. | Risk: single-product revenue concentration >70% on Oud Perfume 50ml (P003). |
| 05 | `05_stockout_risk.xlsx` | Taiba Mart | Inventory Signal Detection: fast-rising demand on Wireless Earbuds against low stock + long supplier lead time. | Risk: stock-out risk on P005 - ~14 units on hand, 21-day lead time, demand up ~3.5x in the last 30 days. |
| 06 | `06_overstock_slow_moving.xlsx` | Nakhla Depot | Inventory Signal Detection: two SKUs barely sell but carry very high stock (slow-moving / overstock). | Risk: overstock exposure on Scented Candle Set (P006) and Reusable Water Bottle (P004). |
| 07 | `07_customer_concentration_churn.xlsx` | Sahem B2B Supplies | Customer Signal Detection: 5 VIP customers dominate revenue; 15 previously-active customers go quiet after day 90. | Risk: revenue concentration in top customers + churn alert for the 'CHNxxxx' customer cohort after ~day 90. |
| 08 | `08_falling_repeat_purchase.xlsx` | Lively Living Store | Customer Signal Detection: the mix shifts from repeat buyers toward one-time buyers over 180 days. | Risk: falling repeat-purchase rate trend, most visible in the final 60-90 days. |
| 09 | `09_margin_decline_cash_pressure.xlsx` | Faisaliah Traders | Profit & Cash Signal Detection: rising cancellations/returns plus two SKUs with cost creeping toward price. | Risk: margin compression on P003/P005 and a rising refund/cancellation rate eating into net revenue after day ~60. |
| 10 | `10_growth_opportunity_crosssell.xlsx` | Sundus Gourmet | Opportunity Signal Detection: Coffee + Dates both trending up and frequently bought together. | Opportunity: growing-demand products (P001, P002) and a clear cross-sell/bundle pair. |
| 11 | `11_seasonal_demand_pattern.xlsx` | Hilal Seasonal Goods | Opportunity Signal Detection: a clear seasonal demand bulge (Dates + Perfume) in a mid-period window. | Opportunity: seasonal pattern detected around days 70-100, reverting to baseline afterward. |
| 12 | `12_messy_dirty_data.xlsx` | Test Co (Data-Quality QA) | Data ingestion QA: duplicate rows, mixed date formats, currency-as-text, blanks, negative-quantity typos, inconsistent casing. | Data Quality Score should drop noticeably; cleaning/dedup/validation logic should catch and flag each issue type. |
| 13 | `13_multi_branch_consolidation.xlsx` | Al Rawda Multi-Branch Retail | Multi-branch consolidation: Riyadh growing, Jeddah flat, Dammam declining, same period. | Branch-level breakdown should show divergent health per branch even though the consolidated total looks stable. |
| 14 | `14_sparse_minimal_data.xlsx` | New Launch Boutique | Edge case: only 20 days of history and very few transactions (new business / early-stage upload). | Platform should degrade gracefully - low-confidence or 'insufficient data' messaging instead of a false forecast. |
| 15 | `15_large_volume_stress.xlsx` | Scale Test Distribution Co. | Performance/volume test: 3 branches x 200 days, ~500 customers, several thousand order lines. | Upload, cleaning and analysis should complete without timeout/performance errors at this row count. |
